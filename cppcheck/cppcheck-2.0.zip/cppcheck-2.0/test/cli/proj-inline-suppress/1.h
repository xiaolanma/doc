
// cppcheck-suppress zerodiv
const int x = 10000 / 0;


